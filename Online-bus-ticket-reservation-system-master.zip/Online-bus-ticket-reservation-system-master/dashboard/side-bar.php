<div class="side-bar">
    <div id="left" class="span3">

        <div class="sidenav">
            <a href="index.php">Home <i class="fa fa-home pull-right"></i></a>
            <a href="add_district.php"> Add Location <i class="fa fa-list-alt pull-right"></i></a>
            <a href="add_company.php">Bus company<i class="fa fa-upload pull-right"></i></a>
            <a href="busWithlocation.php">Add Bus with Place <i class="fa fa-upload pull-right"></i></a>
            <a href="work-order.php">Booking Ticket<i class="fa fa-plus-square pull-right"></i></a>
            <a href="booking_conform.php">Conform Ticket<i class="fa fa-plus-square pull-right"></i></a>
            <a href="message.php">User Message<i class="fa fa-plus-square pull-right"></i></a>
            <!-- <a href="bill-payment.php">Bill Payment<i class="fa fa-minus-square pull-right"></i></a> -->
            <!-- <a href="edit-ledger.php">Edit Ledger<i class="fa fa-book pull-right"></i></a> -->
            <!-- <button class="dropdown-btn">Bank Reconciliations  <i class="fa fa-caret-down"></i>
                <i class="fa fa-folder-open pull-right"></i>
            </button>
            <div class="dropdown-container">
                <a href="receive-cheque.php"class="dropdown-btn"style="display: block">Receive cheques 
                    <i class="fa fa-hand-o-left pull-right"></i>
                </a>
                <a href="paymnt-cheque.php" class="dropdown-btn">Payment cheques 
                    <i class="fa fa-hand-o-left pull-right"></i>
                </a>
            </div> -->
            

           
           
        </div>
    </div>
</div>

