<?php 
include'login.php';
$lgout = new Login();
$logout = $lgout->logout();

 ?>