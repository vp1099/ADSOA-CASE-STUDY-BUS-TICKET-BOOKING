# Online-bus-ticket-reservation-system

> _People can reserve tickets from any part of the world via internet_

### Focus on
* Online bus ticketing system
* Electronic payment system web development
* Online reservation system
* Routes plan
* Price and Seat plan

#### Some Screenshots of this app
 Destination                                | Select your seats                           | After buy seats                         		                    
:------------------------------------------:|:-------------------------------------------:|:-------------------------------------------:
 <img src="Project files/ticket.PNG" width="350"> | <img src="Project files/ticket1.PNG" width="350"> | <img src="Project files/ticket2.PNG" width="350"> 
